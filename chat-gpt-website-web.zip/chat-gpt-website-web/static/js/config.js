const config = {
    // gpt3.5 官方接口：https://api.openai.com/v1/chat/completions
    url: "https://open.aiproxy.xyz/v1/chat/completions",  // gpt3.5代理接口
    apiKey: ""  // openAi Base64 编码 apiKey
};  